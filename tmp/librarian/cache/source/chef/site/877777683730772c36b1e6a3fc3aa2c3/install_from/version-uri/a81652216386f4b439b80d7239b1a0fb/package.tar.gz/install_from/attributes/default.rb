
default[:install_from][:apache_mirror] = 'http://apache.mirrors.tds.net'
